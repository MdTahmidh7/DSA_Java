package FactoryDP;

public interface Lab {
    void showDetails();
}
