package FactoryDP;

public class Lab1 implements Lab{

    @Override
    public void showDetails() {
        System.out.println("Processor : Core i5 -10400");
        System.out.println("Ram : 8Gb 3200GHz");
        System.out.println("Hard Disk : 1TB HDD");
        System.out.println("Monitor  : 18 inch HD");
    }
}
