package FactoryDP;

public class Lab3 implements Lab{
    @Override
    public void showDetails() {
        System.out.println("Processor : Core i7 -10700");
        System.out.println("Ram : 8Gb 2800GHz");
        System.out.println("Hard Disk : 512GB HDD + 256 GB SSD");
        System.out.println("Monitor  : 22 inch FHD");
    }
}
