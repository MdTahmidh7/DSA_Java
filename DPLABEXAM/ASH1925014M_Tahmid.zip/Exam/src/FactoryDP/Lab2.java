package FactoryDP;

public class Lab2 implements Lab{
    @Override
    public void showDetails() {
        System.out.println("Processor : Core i5 -11400");
        System.out.println("Ram : 8Gb 3600GHz");
        System.out.println("Hard Disk : 1TB HDD");
        System.out.println("Monitor  : 21 inch FHD");
    }
}
