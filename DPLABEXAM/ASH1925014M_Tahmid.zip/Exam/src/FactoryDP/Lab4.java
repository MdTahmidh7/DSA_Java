package FactoryDP;

public class Lab4 implements Lab{
    @Override
    public void showDetails() {
        System.out.println("Processor : Core i7 -11700");
        System.out.println("Ram : 8Gb 3600GHz");
        System.out.println("Hard Disk : 1TB HDD + 256 GB SSD");
        System.out.println("Monitor  : 24 inch FHD");
    }
}
