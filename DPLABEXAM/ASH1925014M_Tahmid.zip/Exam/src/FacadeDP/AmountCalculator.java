package FacadeDP;

public class AmountCalculator {
    void debit(){
        System.out.println("AmountCalculator : 10000 Taka has been debited");
    }
}
