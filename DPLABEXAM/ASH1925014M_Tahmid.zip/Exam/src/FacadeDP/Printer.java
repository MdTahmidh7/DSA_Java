package FacadeDP;

public class Printer {
    public void print(String acNumber){
        System.out.println("Printer : Taka has been deducted form "+acNumber);
    }
}
