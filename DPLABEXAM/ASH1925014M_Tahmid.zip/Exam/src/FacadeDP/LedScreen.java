package FacadeDP;

public class LedScreen {
    void showOutput(){
        System.out.println("LedScreen : Transaction has been completed" +
                "successfully");
    }
}
