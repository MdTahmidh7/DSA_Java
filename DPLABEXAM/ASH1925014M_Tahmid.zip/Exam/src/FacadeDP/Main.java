package FacadeDP;

public class Main {
    public static void main(String[] args) {
        DebitCard card = new DebitCard("012-3456-7890");
        card.withdraw();
    }
}
