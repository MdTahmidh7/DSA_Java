package FacadeDP;

public class CentralDataBase {
    void accountIsValid(){
        System.out.println("CentralDataBase : Valid Account : 10000" +
                " Taka can be withdrawn");
    }
}
