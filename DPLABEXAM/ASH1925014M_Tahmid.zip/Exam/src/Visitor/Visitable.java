package Visitor;

public interface Visitable {
    void accept(Visitor visitor);
}
